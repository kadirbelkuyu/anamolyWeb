<!-- Main content -->
<section class="content">
    <!-- Default box -->
	<?php echo form_open_multipart(); ?>
    <div class="box">
        <div class="box-header with-border">
			<?php
				if(!empty($field) && !empty($field->$primary_key))
				{
					$updBtn=_l("Update");
				}
				else
				{
					$updBtn=_l("Add");
				}
			?>
            <h3 class="box-title"><?php echo _l("Product Stock"); ?> / <?php echo $updBtn; ?></h3>

            <div class="box-tools pull-right">
				<?php echo '<button type="submit" class="btn btn-primary btn-flat btn-sm">'.$updBtn.'</button>&nbsp;'; ?>
				<?php echo "<a class='btn btn-danger btn-flat btn-sm' href='"._back_url()."'>"._l("Cancel")."</a>"; ?>
				<a href="<?php echo _back_url();?>" class="btn btn-box-tool btn-bitbucket"><i class="fa fa-list"></i> <?php echo _l("List"); ?></a>
            </div>
        </div>
        <div class="box-body">
            <?php
            echo "<blockquote>";
            echo _l("Product Stock");
            echo "</blockquote>";
            echo _get_flash_message();
            
            if(!empty($field) && !empty($field->$primary_key)){
                echo _input_field("id","",(!empty($field) && !empty($field->$primary_key)) ? _encrypt_val($field->$primary_key) : "","hidden"); // hidden field use for edit item
            }       
			
            echo _select("product_id",$products,_l("Product")."<span class='text-danger'>*</span>",array("product_id","product_name_nl"),_get_post_back($field,'product_id'),array("data-validation"=>"required"),array("form_group_class"=>"col-md-4"));
            echo _input_field("qty", _l("Qty")."<span class='text-danger'>*</span>", _get_post_back($field,'qty','','1'), 'number', array("data-validation" =>"required","step"=>"1","maxlength"=>255,"minvalue"=>"1"),array(),"col-md-4");
            echo _input_field("stock_date", _l("Date")."<span class='text-danger'>*</span>", _get_post_back($field,'stock_date'), 'text', array("data-validation" =>"required","maxlength"=>255,"readonly"=>"readonly"),array(),"col-md-4","datepicker");
            
			?>	
		
			<?php
			echo "<div class='clearfix'></div>";
			
			echo '<div class="col-md-12">
				<br>
				<button type="submit" class="btn btn-primary btn-flat">'.$updBtn.'</button>&nbsp;';
			echo "<a class='btn btn-danger btn-flat' href='"._back_url()."'>"._l("Cancel")."</a>";
			echo '</div>';
            
            ?>
        </div>
    </div>
	<?php echo form_close(); ?>
    <!-- /.box -->
</section>