<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Setting extends MY_Controller {
    protected $controller;
    protected $table_name;
    protected $primary_key;
    protected $data;
    public function __construct()
    {
        parent::__construct();
        $this->controller = $this->router->fetch_class();
        
        if(!_is_admin() && !_is_sub_admin()){
            redirect("login");
            exit();
            
        }
    }

    /**
	* setting
	* @return setting page
	*/
    public function index(){
        if(!_is_admin() && !_is_sub_admin("setting")){
            redirect("login");
            exit();
        }
            $id = _get_current_user_id();
            
			if($_POST)
            {
                $post = $this->input->post();
                add_options($post,"general_setting",true,true);
            }
            $setting =  get_options_by_type("general_setting");//get_options(array("name","copyright","website","currency","currency_symbol","gateway_charges"));
            
            $this->data["field"] = $setting;
			
            $this->data["page_content"] = $this->load->view("admin/settings/general_setting",$this->data,true);
            $this->load->view(BASE_TEMPLATE,$this->data);
    }
    public function app(){
        if(!_is_admin() && !_is_sub_admin("setting/app")){
            redirect("login");
            exit();
        }
        $id = _get_current_user_id();
        
        if($_POST)
        {
            $post = $this->input->post();
            add_options($post,"app_setting",true,true);
        }
        $setting = get_options_by_type("app_setting");
        
        $this->data["field"] = $setting;
        $this->data["page_content"] = $this->load->view("admin/settings/app_setting",$this->data,true);
        $this->load->view(BASE_TEMPLATE,$this->data);
    }
	function email(){
        if(!_is_admin() && !_is_sub_admin("setting/email")){
            redirect("login");
            exit();
        }
        $id = _get_current_user_id();
            
			if($_POST)
            {
                $post = $this->input->post();
                add_options($post,"sendgrid",true,true);
            }
            $setting = get_options(array("email_sender","sendgrid_id","sendgrid_key","receiver_email"));
            
            $this->data["field"] = $setting;
			
            $this->data["page_content"] = $this->load->view("admin/settings/email",$this->data,true);
            $this->load->view(BASE_TEMPLATE,$this->data);
    }
    function billing(){
        if(!_is_admin() && !_is_sub_admin("setting/billing")){
            redirect("login");
            exit();
        }
        $id = _get_current_user_id();
            
			if($_POST)
            {
                $post = $this->input->post();
                add_options($post,"billing",true,true);
            }
            $setting = get_options_by_type("billing");
            
            $this->data["field"] = $setting;
			
            $this->data["page_content"] = $this->load->view("admin/settings/billing",$this->data,true);
            $this->load->view(BASE_TEMPLATE,$this->data);
    }
}
