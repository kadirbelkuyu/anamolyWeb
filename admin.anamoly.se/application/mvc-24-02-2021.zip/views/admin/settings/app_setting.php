<!-- Main content -->
<section class="content">
    <!-- Default box -->
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo _l("App Settings"); ?></h3>

            <div class="box-tools pull-right">
            </div>
        </div>
        <div class="box-body">
            <?php
            echo "<blockquote>";
            echo _l("App Settings");
            echo "</blockquote>";
            echo _get_flash_message();
            echo form_open_multipart();
			echo _input_field("app_contact", _l("Contact No.")."<span class='text-danger'>*</span>", _get_post_back($field,'app_contact'), 'text', array("data-validation" =>"number","maxlength"=>255),array(),"col-md-4");
			echo _input_field("app_whatsapp", _l("Whatsapp No")."<span class='text-danger'>*</span>", _get_post_back($field,'app_whatsapp'), 'text', array("data-validation" =>"required","maxlength"=>255),array(),"col-md-4");
            echo _input_field("app_email", _l("Email ID")."<span class='text-danger'>*</span>", _get_post_back($field,'app_email'), 'email', array("data-validation" =>"email","maxlength"=>255),array(),"col-md-4");
		    echo '<div class="clearfix"></div>';
        
			echo '<div class="col-md-12">
				<button type="submit" class="btn btn-primary btn-flat">'._l("Save").'</button>&nbsp;';
			echo '</div>';
            echo form_close();
            ?>
        </div>
    </div>
    <!-- /.box -->
</section>