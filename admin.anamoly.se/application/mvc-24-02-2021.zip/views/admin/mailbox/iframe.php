
              
              <!-- /.mailbox-controls -->
              <div class="mailbox-read-message">
                <?php echo $data["body"]["text/html"]; ?>
              </div>
              